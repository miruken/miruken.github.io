eval(miruken.mvc.namespace);

mytodoApp.export(
    "AboutController",
    Controller.extend({
        awesomeThings: [
           'HTML5 Boilerplate',
           'AngularJS',
           'Karma'
        ]
    }));